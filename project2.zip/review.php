<html>
        <body>
          <?php                                                                                                                                                                                             
                                                                                                                                                                                                            
           $db = new mysqli('localhost', 'cs143', '', 'class_db');                                                                                                                                          
           if ($db->connect_errno > 0)
          {
          die('Unable to connect to database [' . $db->connect_error . ']');
          }



        if(isset($_POST["id"]) )
          {

          $query = "select id from Movie where id={$_POST['id']}";

          $rs = $db->query($query);
          if(mysqli_num_rows($rs) == 0)
          {
          echo "No such Movie";
          exit();
          }
          }
          if(isset($_POST['SubmitButton']))
          {
          $name = "{$_POST['name']}";
          $rating = (int)$_POST['rating'];
          $comment = "{$_POST['comment']}";

          if(isset($_POST['id']))
          {
          $mid=$_GET['id'];
          }
          else
          {
          $mid = (int)$_GET['id'];
          }

          $insert = "Insert into Review(name, time, mid, rating, comment) Values('$name',NOW(),$mid,$rating,'$comment')";
          if ($db->query($insert) === TRUE) {
          echo "Review added!";
          } else {
          echo "Error: " . $query. "<br>" . $db->error;
          }
          }
         else
          {
          $name = "{$_GET['name']}";
          $rating = (int)$_GET['rating'];
          $comment = "{$_GET['comment']}";
          $mid = $_GET['mid'];

          $insert = "Insert into Review(name, time, mid, rating, comment) Values('$name',NOW(),$mid,$rating,'$comment')";

          if ($db->query($insert) === TRUE) {
          echo "Review added!";
          } else {
          echo "Error: " . $query. "<br>" . $db->error;
          }
          }

          ?>



          <form action = "" method = "POST">
            <label> Movie ID: </label>
            <select name="mid" type="submit" > <option> <?php echo "{$_GET['id']}"; ?></option> </select><br></br>
            Name: <input type = "text" name = "name" value="Mr.Anonymous" /><br></br>
            Rating: <select type = "number" name = "rating"> <option value="1"> 1 </option> <option value="2"> 2 </option> <option value="3"> 3 </option> <option value="4"> 4 </option> <option value = "5\
"> 5 </option> </select><br/><br/>
            Comment:<br/> <textarea name="comment" type="text" rows="5" cols="40" value=""></textarea><br></br>
            <input type = "submit" name = "SubmitButton" />
          </form>



        </body>
</html>

