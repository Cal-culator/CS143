<?php
   if( $_GET["id"] ) {

      $db = new mysqli('localhost', 'cs143', '', 'class_db');
      if ($db->connect_errno > 0) {
         die('Unable to connect to database [' . $db->connect_error . ']');
      }

      $queryActor = "select first, last, sex, dob, dod from Actor where id={$_GET['id']}";
      $rsActor = $db->query($queryActor);
      if(mysqli_num_rows($rsActor) == 0)
      {
        echo "No actors found";
        exit();
      }


      $query = "select first,last,title,sex,dob,dod,mid from Actor as A, MovieActor as MA,Movie as M where A.id=MA.aid AND MA.mid=M.id AND A.id ={$_GET['id']}";

    $rs = $db->query($query);

    if(mysqli_num_rows($rs) == 0)
    {
     	$rowActor = $rsActor ->fetch_assoc();
        $first = $rowActor['first'];
        $last = $rowActor['last'];
        $sex = $rowActor['sex'];
	$dob = $rowActor['dob'];
        $dod = $rowActor['dod'];

        if(empty($dod))
	{
        $dod = "Still Alive";
	}

        echo "DOB: $dob, Sex: $sex, DOD: $dod <br/>";
	echo "No movies found for $first $last.";
	exit();
    }


    $count=0;

    while ($row = $rs->fetch_assoc()) {
          $first = $row['first'];
          $last = $row['last'];
          $title = $row['title'];
          $mid = $row['mid'];
          $sex = $row['sex'];
          $dob = $row['dob'];
          $dod = $row['dod'];

          if(empty($dod))
          {
          $dod="Still Alive";
          }

          if($count==0){

		echo "DOB: $dob, Sex: $sex, DOD: $dod <br/>";
		echo "The movies that Actor $first $last stars in<br><br>";
		$count++;
          }

          $url = "http://localhost:8888/movie.php?id=$mid";
          echo "<a href=$url>$title</a><br>";
          }

      exit();
   }
?>