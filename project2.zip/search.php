<html>
  <body>

        <?php                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                
        $db = new mysqli('localhost', 'cs143', '', 'class_db');                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                
        if ($db->connect_errno > 0)
        {
           die('Unable to connect to database [' . $db->connect_error . ']');
        }

        //ACTOR
        if( isset($_GET["actor"]))
        {
        $toParse = $_GET["actor"];
        $pieces = explode(" ", $toParse);

        if(count($pieces) == 2)
        {
        $pieces[0] = ucfirst(strtolower($pieces[0]));
        $pieces[1] = ucfirst(strtolower($pieces[1]));

        $query = "select first, last, dob, id from Actor where first LIKE '%{$pieces[0]}%' AND last LIKE '%{$pieces[1]}%'";
        }
        if(count($pieces) == 1)
        {
        $pieces[0] = ucfirst(strtolower($pieces[0]));
        $query = "select first, last, dob, id from Actor where first LIKE '%{$pieces[0]}%' OR last LIKE '%{$pieces[0]}%'";
        }
        if(empty($toParse))
        {
        $query = "select first, last, dob, id from Actor";
        }

        $rsA = $db ->query($query);

        $count = 0;

        if(mysqli_num_rows($rsA) == 0)
        {
        echo "No actors found";
                echo "<form action = '/search.php' method = 'GET'>                                                                                                                                                                                                              
        Actor: <input type = 'text' name = 'actor' />                                                                                                                                                                                                                           
        <input  type = 'submit' ></input>                                                                                                                                                                                                                                       
        </form>                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                
        <form action = '/search.php' method = 'GET' >                                                                                                                                                                                                                           
          Movie: <input type = 'text' name = 'movie' />                                                                                                                                                                                                                         
          <input  type='submit'></input>                                                                                                                                                                                                                                        
        </form>";

        exit();
        }
        }

        //MOVIES
        if( isset($_GET["movie"]))
        {
        $var = $_GET["movie"];

        if(empty($var))
        {
        $queryM = "select title, year, id from Movie";

        }
        else
        {

        $lowvar = strtolower($var);
        //$queryM = "select title, year, id from Movie where LOWER(title) LIKE '%{$lowvar}%'";


        $movieParse = explode(" ", $lowvar);
        $queryM = "SELECT title, year, id FROM Movie WHERE title LIKE LOWER(";
        for ($i = 0; $i < count($movieParse); $i++)
        {
        if($i < (count($movieParse) - 1))
        {
        $queryM .= "'%" . $movieParse[$i] . "%') AND title LIKE LOWER(";
        }
        else
        {
          $queryM .= "'%" . $movieParse[$i];
        }
        }

        $queryM .= "%') ORDER BY title;";


        }

        $rsM = $db ->query($queryM);

        $count = 0;

        if(mysqli_num_rows($rsM) == 0)
        {
        echo "No movies found";
        echo "<form action = '/search.php' method = 'GET'>                                                                                                                                                                                                                      
        Actor: <input type = 'text' name = 'actor' />                                                                                                                                                                                                                           
        <input  type = 'submit' ></input>                                                                                                                                                                                                                                       
        </form>                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                
        <form action = '/search.php' method = 'GET' >                                                                                                                                                                                                                           
          Movie: <input type = 'text' name = 'movie' />                                                                                                                                                                                                                         
          <input  type='submit'></input>                                                                                                                                                                                                                                        
        </form>";
        exit();
        }

        }

        ?>

        <form action = "/search.php" method = "GET">
        Actor: <input type = "text" name = "actor" />
        <input  type = "submit" ></input>
        </form>


        <form action = "/search.php" method = "GET" >
          Movie: <input type = "text" name = "movie" />
          <input  type="submit"></input>
        </form>

        <?php                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                
         if(isset($_GET["movie"]))                                                                                                                                                                                                                                              
         {                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                
        while ($rowMovie = $rsM->fetch_assoc()) {

               $title = $rowMovie['title'];
               $year = $rowMovie['year'];
               $id = (int)$rowMovie['id'];

               if($count==0){
                  echo "List of Movies <br /><br />";
                  $count = 1;
               }

               $url = "movie.php?id=$id";
               echo "Movie Title: ";
               echo "<a href=$url>$title </a><br />";
               echo "Year Released: ";
               echo "<a href=$url>$year </a><br /><br />";
            }
        }
        if(isset($_GET["actor"]))
        {
        while ($rowActor = $rsA->fetch_assoc()) {
               $first = $rowActor['first'];
               $last = $rowActor['last'];
               $dob = $rowActor['dob'];
               $id = $rowActor['id'];

               if($count==0){
                  echo "List of Actors <br /><br />";
                  $count = 1;
               }

               $url = "actor.php?id=$id";
               echo "Actor: ";
               echo "<a href=$url>$first $last </a><br />";
               echo "DOB: ";
               echo "<a href=$url>$dob </a><br /><br />";
        }
        }
        ?>

        </body>
</html>




