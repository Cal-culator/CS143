<?php
   if( $_GET["id"] ) {

      $db = new mysqli('localhost', 'cs143', '', 'class_db');
      if ($db->connect_errno > 0) {
         die('Unable to connect to database [' . $db->connect_error . ']');
      }

      $queryMovie = "select title, id from Movie where id={$_GET['id']}";
      $rsMovie = $db->query($queryMovie);
      if(mysqli_num_rows($rsMovie) == 0)
      {
        echo "No movies found";
        exit();
      }

      //all actor queries
      $actorname = "select first,last,title,aid from Actor as A, MovieActor as MA,Movie as M where A.id=MA.aid AND MA.mid=M.id AND M.id ={$_GET['id']}";

    $AN = $db->query($actorname);

    if(mysqli_num_rows($AN) == 0)
    {
        $rowMovie = $rsMovie ->fetch_assoc();
        $title = $rowMovie['title'];

        $urlrev = "http://localhost:8888/review.php?id={$_GET["id"]}";

        echo "No actors found for $title.<br/>";
        echo "<a href=$urlrev><button>Write a Review!</button></a>";
        exit();
    }

    $count = 0;

    while ($row = $AN->fetch_assoc()) {
          $first = $row['first'];
          $last = $row['last'];
          $title = $row['title'];
          $aid = $row['aid'];

          if($count==0){
                echo "Actors for the movie: $title<br>";
                $count++;
          }

          $url = "http://localhost:8888/actor.php?id=$aid";
          echo "<a href=$url>$first $last</a><br>";

    }

    //rating queries
    $avgrat = "select AVG(rating) from Review as R where mid={$_GET['id']}";
    $AR = $db->query($avgrat);
    while ($row = $AR->fetch_assoc()) {
          $rat = $row['AVG(rating)'];
          echo "<br>Average rating: $rat<br>";
    }

    //reviews queries
    echo "<br>User Reviews<br>";
    $rev = "Select name, comment From Review where mid={$_GET['id']}";
    $Allrev = $db->query($rev);
    while ($row = $Allrev->fetch_assoc()) {
          $comment = $row['comment'];
          $name = $row['name'];
          echo "$name said: $comment<br>";
    }

    $row = $rsMovie->fetch_assoc();
    $id = $row['id'];
    $urlrev = "http://localhost:8888/review.php?id=$id";
    echo "<a href=$urlrev><button>Add comment</button></a>";

      exit();
   }
?>
