DROP TABLE if exists Laureates;
DROP TABLE if exists Person;
Drop table if exists Org;
Drop table if exists nobelPrizes;

CREATE TABLE Laureates(id int, entityType varchar(100), PRIMARY KEY(id));
CREATE TABLE Person(id int, givenName varchar(100), familyName varchar(100), gender varchar(100), birthDate varchar(100), birthCity varchar(100), birthCountry varchar(100), PRIMARY KEY(id));
CREATE TABLE Org(id int, orgName varchar(100), foundedDate varchar(100), foundedCity varchar(100), foundedCountry varchar(100), PRIMARY KEY(id));
CREATE TABLE nobelPrizes(id int, awardYear varchar(100), category varchar(100), sortOrder int, affiliationName varchar(100), affiliationCity varchar(100), affiliationCountry varchar(100), locationString varchar(100), PRIMARY KEY(id,awardYear,category,affiliationName));


LOAD DATA LOCAL INFILE './Org.del' INTO TABLE Org FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"';

LOAD DATA LOCAL INFILE './Laureates.del' INTO TABLE Laureates FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"';

LOAD DATA LOCAL INFILE './Person.del' INTO TABLE Person FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"';

LOAD DATA LOCAL INFILE './nobelPrizes.del' INTO TABLE nobelPrizes FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"';
