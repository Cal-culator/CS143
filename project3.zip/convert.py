import json
"""
Laureates( ID, entityType)
-Laureate = [id, "Org"]

//see specs if city+country can be combined
Person(id, knownName, gender, date, birth,place)
- Person = [id, knownName, gender, birthDate, locationString]

Org(id, orgName, founded-date, founded-place)
-  Org = [id, orgName, foundedDate, locationString]

nobelPrizes(id, awardYear, category, sortOrder, affiliation-name, affiliation-city, affiliation-country)
- prize = [id, awardYear, category, sortOrder, affiliationName, locationString]
"""


# load data
data = json.load(open("/home/cs143/data/nobel-laureates.json", "r"))

# get the id, givenName, and familyName of the first laureate

#first array is table, second table is tuples (rows)
tables = []

ids = []

for x in range(0,len(data["laureates"])):
    laureate = data["laureates"][x]

    id = laureate["id"]

    if id in ids:
        continue

    ids.append(id)

    #organization table
    if "orgName" in laureate.keys():
        orgName = laureate["orgName"]["en"]
        orgName = "\"" + orgName+"\""
        foundedDate = ""
        foundedCity = ""
        foundedCountry = ""

        if "founded" in laureate.keys():
            foundedDate = laureate["founded"]["date"]
            foundedDate = "\"" + foundedDate+"\""

            if "place" in laureate["founded"].keys():
                if "city" in laureate["founded"]["place"].keys():
                    foundedCity = laureate["founded"]["place"]["city"]["en"]
                    foundedCity = "\"" + foundedCity+"\""
                else:
                    foundedCity = "NULL"

                if "country" in laureate["founded"]["place"].keys():
                    foundedCountry = laureate["founded"]["place"]["country"]["en"]
                    foundedCountry = "\"" + foundedCountry+"\""
                else:
                    foundedCountry = "NULL"

        else:
            foundedDate = "NULL"
            foundedCity = "NULL"
            foundedCountry = "NULL"

        

        Org = [id, orgName, foundedDate, foundedCity, foundedCountry]

        NobelPrize = []
        #nobel prize table
        for y in range(0,len(laureate["nobelPrizes"])):

            awardYear = laureate["nobelPrizes"][y]["awardYear"]
            awardYear = "\"" + awardYear+"\""
            category = laureate["nobelPrizes"][y]["category"]["en"]
            category = "\"" + category+"\""
            sortOrder = laureate["nobelPrizes"][y]["sortOrder"]
            

            if "affiliations" in laureate["nobelPrizes"][y].keys():
                for z in range(0,len(laureate["nobelPrizes"][y]["affiliations"])):
                    affiliationName = laureate["nobelPrizes"][y]["affiliations"][z]["name"]["en"]
                    affiliationName = "\"" + affiliationName+"\""
                    affiliationCity = ""
                    affiliationCountry = ""

                    if "city" in laureate["nobelPrizes"][y]["affiliations"][z].keys():
                        affiliationCity = laureate["nobelPrizes"][y]["affiliations"][z]["city"]["en"]
                        affiliationCity = "\"" + affiliationCity+"\""
                    else:
                        affiliationCity = "NULL"

                    if "country" in laureate["nobelPrizes"][y]["affiliations"][z].keys():
                        affiliationCountry = laureate["nobelPrizes"][y]["affiliations"][z]["country"]["en"]
                        affiliationCountry = "\"" + affiliationCountry+"\""
                    else:
                        affiliationCountry = "NULL"

                    locationString = laureate["nobelPrizes"][y]["affiliations"][z]["locationString"]["en"]
                    locationString = "\"" + locationString+"\""
                    prize = [id, awardYear, category, sortOrder, affiliationName, affiliationCity, affiliationCountry, locationString]
                    NobelPrize.append(prize)
            else:
                    affiliationName = "NULL"
                    locationString = "NULL"
                    affiliationCity = "NULL"
                    affiliationCountry = "NULL"
                    prize = [id, awardYear, category, sortOrder, affiliationName, affiliationCity, affiliationCountry, locationString]
                    NobelPrize.append(prize)

        Organization = "Org"
        Laureate = [id, "\"" + Organization+"\""]

        row = [Laureate, [""], Org, NobelPrize]

        tables.append(row)

    #person table
    if "knownName" in laureate.keys():

        givenName = ""
        if "givenName" in laureate.keys():
            givenName = laureate["givenName"]["en"]
            givenName = "\"" + givenName+"\""
        else:
            givenName  = "NULL"

        familyName = ""
        if "familyName" in laureate.keys():
            familyName = laureate["familyName"]["en"]
            familyName = "\"" + familyName+"\""
        else:
            familyName = "NULL"

        gender = laureate["gender"]
        gender = "\"" + gender+"\""
        birthDate = ""
        birthCity = ""
        birthCountry = ""
        
        if "birth" in laureate.keys():
            birthDate = laureate["birth"]["date"]
            birthDate = "\"" + birthDate+"\""

            if "place" in laureate["birth"].keys():
                if "city" in laureate["birth"]["place"].keys():
                    birthCity = laureate["birth"]["place"]["city"]["en"]
                    birthCity = "\"" + birthCity+"\""
                else:
                    birthCity = "NULL"

                if "country" in laureate["birth"]["place"].keys():
                    birthCountry = laureate["birth"]["place"]["country"]["en"]
                    birthCountry = "\"" + birthCountry+"\""

            else:
                birthCity = "NULL"
                birthCountry = "NULL"

        else:
            birthDate = "NULL"

            if "birthCountry" in laureate.keys():
                birthCountry = laureate["birthCountry"]["en"]
                birthCountry = "\"" + birthCountry+"\""
            else:
                birthCountry = "NULL"

            if "birthCity" in laureate.keys():
                birthCity = laureate["birthCity"]["en"]
                birthCity = "\"" + birthCity+"\""
            else:
                birthCity = "NULL"

        Person = [id, givenName, familyName, gender, birthDate, birthCity, birthCountry]

        EPerson = "Person"
        Laureate = [id, "\"" + EPerson+"\""]

        NobelPrize = []
        #nobel prize table
        for y in range(0,len(laureate["nobelPrizes"])):
            awardYear = laureate["nobelPrizes"][y]["awardYear"]
            awardYear = "\"" + awardYear+"\""
            category = laureate["nobelPrizes"][y]["category"]["en"]
            category = "\"" + category+"\""
            sortOrder = laureate["nobelPrizes"][y]["sortOrder"]

            if "affiliations" in laureate["nobelPrizes"][y].keys():
                for z in range(0,len(laureate["nobelPrizes"][y]["affiliations"])):
                    affiliationName = laureate["nobelPrizes"][y]["affiliations"][z]["name"]["en"]
                    affiliationName = "\"" + affiliationName+"\""
                    affiliationCity = ""
                    affiliationCountry = ""

                    if "city" in laureate["nobelPrizes"][y]["affiliations"][z].keys():
                        affiliationCity = laureate["nobelPrizes"][y]["affiliations"][z]["city"]["en"]
                        affiliationCity = "\"" + affiliationCity+"\""
                    else:
                        affiliationCity = "NULL"

                    if "country" in laureate["nobelPrizes"][y]["affiliations"][z].keys():
                        affiliationCountry = laureate["nobelPrizes"][y]["affiliations"][z]["country"]["en"]
                        affiliationCountry = "\"" + affiliationCountry+"\""
                    else:
                        affiliationCountry = "NULL"


                    locationString = laureate["nobelPrizes"][y]["affiliations"][z]["locationString"]["en"]
                    locationString = "\"" + locationString+"\""
                    prize = [id, awardYear, category, sortOrder, affiliationName, affiliationCity, affiliationCountry, locationString]
                    NobelPrize.append(prize)
            else:
                    affiliationName = "NULL"
                    locationString = "NULL"
                    affiliationCity = "NULL"
                    affiliationCountry =  "NULL"
                    prize = [id, awardYear, category, sortOrder, affiliationName, affiliationCity, affiliationCountry, locationString]
                    NobelPrize.append(prize)

        row = [Laureate, Person, [""], NobelPrize]

        tables.append(row)




#Laureate
for x in tables: 
    combine1 = ','.join(x[0])
    f = open("Laureates.del", "a")
    f.write(combine1 + '\n')
    f.close()

#Person
for x in tables: 
    combine1 = ','.join(x[1])
    if combine1 == '':
        continue
    f = open("Person.del", "a")
    f.write(combine1 + '\n')
    f.close()

#Org
for x in tables: 
    combine1 = ','.join(x[2])
    if combine1 == '':
        continue
    f = open("Org.del", "a")
    f.write(combine1 + '\n')
    f.close()

#Nobel Prize
for x in tables:
    for y in x[3]:
        combine1 = ','.join(y)
        f = open("nobelPrizes.del", "a")
        f.write(combine1 + '\n')
        f.close()








    


    


