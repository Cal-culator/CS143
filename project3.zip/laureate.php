<?php

// get the id parameter from the request
$id = intval($_GET['id']);

$db = new mysqli('localhost', 'cs143', '', 'class_db');
if ($db->connect_errno > 0) {
   die('Unable to connect to database [' . $db->connect_error . ']');
}

$queryLaureate = "select entityType from Laureates where id={$id}";
$rsLaureate = $db->query($queryLaureate);

//check if there is no such ID
if(mysqli_num_rows($rsLaureate) == 0)
{
    exit();
}

$rowLaureate = $rsLaureate->fetch_assoc();
$ET = $rowLaureate['entityType'];

$queryET = "select * from {$ET} where id = {$id}";
$queryNP = "select * from nobelPrizes where id = {$id}";

$rsET = $db->query($queryET);
$rowET = $rsET->fetch_assoc();

$rsNP = $db->query($queryNP);

$affiliationArr = array();

while ($rowNP = $rsNP->fetch_assoc()) {
    $affiliates = array($rowNP["affiliationName"], $rowNP["affiliationCity"], $rowNP["affiliationCountry"]);
    array_push($affiliationArr, $affiliates);
}

$queryNP = "select * from nobelPrizes where id = {$id}";
$rsNP = $db->query($queryNP);
$rowNP = $rsNP->fetch_assoc();


if(strcmp($ET, "Org") == 0)
{
//CREATE TABLE Org(id int, orgName varchar(100), foundedDate varchar(100),
//foundedCity varchar(100), foundedCountry varchar(100), PRIMARY KEY(id));

    $orgName = $rowET['orgName'];
    $foundedDate = $rowET['foundedDate'];
    $foundedCity = $rowET['foundedCity'];
    $foundedCountry = $rowET['foundedCountry'];

    $orgNameOBJ = (object) ["en" => "{$orgName}"];
    $orgNameOBJ = (object) array_filter((array) $orgNameOBJ);

    $OcountryOBJ = (object) ["en" => "{$foundedCountry}"];
    $OcountryOBJ = (object) array_filter((array) $OcountryOBJ);

    $OcityOBJ = (object) ["en" => "{$foundedCity}"];
    $OcityOBJ = (object) array_filter((array) $OcityOBJ);

    $OplaceOBJ = (object) ["city" => $OcityOBJ, "country" => $OcountryOBJ];
    $OplaceOBJ = (object) array_filter((array) $OplaceOBJ);

    $foundedOBJ = (object) ["date" => "{$foundedDate}", "place" => $OplaceOBJ];
    $foundedOBJ = (object) array_filter((array) $foundedOBJ);

    $awardYear = $rowNP["awardYear"];
    $category = $rowNP["category"];
    $sortOrder= $rowNP["sortOrder"];

    $AcategoryOBJ = (object) ["en" => "{$category}"];
    $AcategoryOBJ = (object) array_filter((array) $AcategoryOBJ);

    $storeA = array();

    foreach($affiliationArr as $item) {

        $ANameOBJ = (object) ["en" => "{$item[0]}"];
        $ANameOBJ = (object) array_filter((array) $ANameOBJ);
    
        $ACityOBJ = (object) ["en" => "{$item[1]}"];
        $ACityOBJ = (object) array_filter((array) $ACityOBJ);
    
        $ACountryOBJ = (object) ["en" => "{$item[2]}"];
        $ACountryOBJ = (object) array_filter((array) $ACountryOBJ);
    
        $affiliationOBJ = (object) ["name" => $ANameOBJ,"city" => $ACityOBJ, "country" => $ACountryOBJ];
        $affiliationOBJ = (object) array_filter((array) $affiliationOBJ);

        array_push($storeA, $affiliationOBJ);
    }


    $AnobelPrizes = array( (object) [
        "awardYear" => strval($awardYear),
        "category" => $AcategoryOBJ,
        "sortOrder" => strval($sortOrder),
        "affiliations" => $storeA ]);

    $output = (object) array(
        "id" => strval($id),
        "orgName" => $orgNameOBJ,
        "founded" => $foundedOBJ,
        "nobelPrizes" => $AnobelPrizes
    );


}
if(strcmp($ET, "Person") == 0)
{
    $givenName = $rowET['givenName'];
    $familyName = $rowET['familyName'];
    $gender = $rowET['gender'];
    $birthDate = $rowET['birthDate'];
    $birthCity = $rowET['birthCity'];
    $birthCountry = $rowET['birthCountry'];

    $givenNameOBJ = (object) ["en" => "{$givenName}"];
    $givenNameOBJ = (object) array_filter((array) $givenNameOBJ);

    $familyNameOBJ = (object) ["en" => "{$familyName}"];
    $familyNameOBJ = (object) array_filter((array) $familyNameOBJ);

    $countryOBJ = (object) ["en" => "{$birthCountry}"];
    $countryOBJ = (object) array_filter((array) $countryOBJ);

    $cityOBJ = (object) ["en" => "{$birthCity}"];
    $cityOBJ = (object) array_filter((array) $cityOBJ);

    $placeOBJ = (object) ["city" => $cityOBJ, "country" => $countryOBJ];
    $placeOBJ = (object) array_filter((array) $placeOBJ);

    $birthOBJ = (object) ["date" => "{$birthDate}", "place" => $placeOBJ];
    $birthOBJ = (object) array_filter((array) $birthOBJ);

    
    $awardYear = $rowNP["awardYear"];
    $category = $rowNP["category"];
    $sortOrder= $rowNP["sortOrder"];
    $affiliationName = $rowNP["affiliationName"];
    $affiliationCity = $rowNP["affiliationCity"];
    $affiliationCountry = $rowNP["affiliationCountry"];

    $AcategoryOBJ = (object) ["en" => "{$category}"];
    $AcategoryOBJ = (object) array_filter((array) $AcategoryOBJ);

    $storeA = array();

    foreach($affiliationArr as $item) {

        $ANameOBJ = (object) ["en" => "{$item[0]}"];
        $ANameOBJ = (object) array_filter((array) $ANameOBJ);
    
        $ACityOBJ = (object) ["en" => "{$item[1]}"];
        $ACityOBJ = (object) array_filter((array) $ACityOBJ);
    
        $ACountryOBJ = (object) ["en" => "{$item[2]}"];
        $ACountryOBJ = (object) array_filter((array) $ACountryOBJ);
    
        $affiliationOBJ = (object) ["name" => $ANameOBJ,"city" => $ACityOBJ, "country" => $ACountryOBJ];
        $affiliationOBJ = (object) array_filter((array) $affiliationOBJ);

        array_push($storeA, $affiliationOBJ);
    }
/*
    foreach($storeA as $item)
    {
        echo $item[0][0];
    }
*/
    $AnobelPrizes = array( (object) [
        "awardYear" => strval($awardYear),
        "category" => $AcategoryOBJ,
        "sortOrder" => strval($sortOrder),
        "affiliations" => $storeA ]);

    $output = (object) array(
        "id" => strval($id),
        "givenName" => $givenNameOBJ,
        "familyName" => $familyNameOBJ,
        "gender" => strval($gender),
        "birth" => $birthOBJ,
        "nobelPrizes" => $AnobelPrizes
    );

    #$object = (object) array_filter((array) $object);

    #echo json_encode(array_filter((array) $object));

}




// set the Content-Type header to JSON,
// so that the client knows that we are returning JSON data
header('Content-Type: application/json');

/*
   Send the following fake JSON as the result
   {  "id": $id,
      "givenName": { "en": "A. Michael" },
      "familyName": { "en": "Spencer" },
      "affiliations": [ "UCLA", "White House" ]
   }
*/


echo json_encode($output, JSON_PRETTY_PRINT);

?>
