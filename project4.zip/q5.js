db.laureates.aggregate([
    {
        $unwind: "$nobelPrizes"
    },
    {
        $match: {"orgName": {$ne: null}}
    },
    {
        $sortByCount: "$nobelPrizes.awardYear"
    },
    {
        $count: "years"
    }
]);