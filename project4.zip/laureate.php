<?php

    $id = intval($_GET['id']);
    $mng = new MongoDB\Driver\Manager("mongodb://localhost:27017");

    $query = new MongoDB\Driver\Query(['id' => "{$id}"]);
    $rows = $mng->executeQuery("nobel.laureates", $query);


    $laureate = current($rows->toArray());
    if (!empty($laureate)) {
        if (is_null($laureate->givenName->en))
        {
            
            $output = (object) array(
                "id" => $laureate->id,
                "orgName" => $laureate->orgName,
                "acronym" => $laureate->acronym,
                "nativeName" => $laureate->nativeName,
                "founded" => $laureate->founded,
                "links" => $laureate->links,
                "nobelPrizes" => $laureate->nobelPrizes
            );
        }
        else
        {
            $output = (object) array(
                "id" => $laureate->id,
                "givenName" => $laureate->givenName,
                "familyName" => $laureate->familyName,
                "fullName" => $laureate->fullName,
                "knownName" => $laureate->knownName,
                "gender" => $laureate->gender,
                "birth" => $laureate->birth,
                "death" => $laureate->death,
                "links" => $laureate->links,
                "nobelPrizes" => $laureate->nobelPrizes
            );
            //$output = (object) array_filter((array) $output);
        }

        //$output = (object) array_filter((array) $output);
        echo json_encode($output, JSON_PRETTY_PRINT);
    } else {
        echo "No match found\n";
    }
?>