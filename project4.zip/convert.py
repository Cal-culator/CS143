import json

# load data
data = json.load(open("/home/cs143/data/nobel-laureates.json", "r"))
combine = ""

for x in range(0,len(data["laureates"])):
    combine += json.dumps(data["laureates"][x]) + "\n"
# get the id, givenName, and familyName of the first laureate


# print the extracted information


f = open("laureates.import", "a")
f.write(combine)
f.close()
