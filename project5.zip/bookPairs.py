from pyspark import SparkContext
from itertools import combinations

sc = SparkContext("local", "bookPairs")

reviews = sc.textFile("/home/cs143/data/goodreads.user.books")

combinationPairs = reviews.flatMap(lambda review: combinations(review.split(":")[1].split(','),2))

onlyPairs = combinationPairs.map(lambda combinationPair: (combinationPair, 1))
pairCounts = onlyPairs.reduceByKey(lambda a, b: a+b)
pairGT20 = pairCounts.filter(lambda pair: pair[1]>20)
pairGT20.saveAsTextFile("./output")

#if already pair, order ascending

#if not in pair, make combinations
    #use this for combinations: https://www.geeksforgeeks.org/permutation-and-combination-in-python/
    #order ascending and remove duplicates
    #have pairs in the same line: Ex - (1,2,3) -> (1,2) (1,3) (2,3)
    #split with flat map into different lines
    #use map (pair, 1)
    #reduceByKey on above

