load data local infile 'movie.del' into table Movie fields terminated by ',' optionally enclosed by '"';

load data local infile 'actor1.del' into table Actor fields terminated by ',' optionally enclosed by '"';

load data local infile 'actor2.del' into table Actor fields terminated by ',' optionally enclosed by '"';

load data local infile 'actor3.del' into table Actor fields terminated by ',' optionally enclosed by '"';

load data local infile 'moviegenre.del' into table MovieGenre fields terminated by ',' optionally enclosed by '"';

load data local infile 'movieactor1.del' into table MovieActor fields terminated by ',' optionally enclosed by '"';

load data local infile 'movieactor2.del' into table MovieActor fields terminated by ',' optionally enclosed by '"';